<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcome to trip</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Edu+SA+Beginner&family=Roboto:wght@300&display=swap" rel="stylesheet">
</head>
<body>
    <img  class= "bg" src="sou.jpg" alt="silver oak university" srcset="">
    <div class="containor">
        <h1>welcome to silver oak  university mumbai trip</h1>
        <p>enter your details and submit this form to confirm your participation in the trip</p>

        <?php
        $insert =false;
         if ($insert ==true){
          echo "<p class='msg'> your response is suceessfull add thannk you for register</p>";
         }
         ?>

      <form action="index.php" method="POST">
       <input type="text" name="name" id="name" placeholder="enter your name">
       <input type="text" name="age" id="age" placeholder="enter your age">
       <input type="text" name="gender" id="gender" placeholder=" enter your gender">
       <input type="email" name="email" id="email" placeholder=" enter your email">
       <input type="phone" name="phone" id="phone" placeholder=" enter your phone">
       <textarea name="desc" id="desc" cols="30" rows="10" placeholder="enter any other informstion here"></textarea>
       <button class="btn">submit</button>
      </form>
    </div>
    <script src="script.js"></script>
    
</body>
</html>

<?php
$insert =false;
if (isset($_POST['name'])) {
$server ="localhost";
$username ="root";
$password ="";

$conn = mysqli_connect ($server, $username, $password);
if(!$conn){
    die (" connection of this database is failled due to" . mysqli_connect_error());
}
//  echo "success to connecting this db";
$name = $_POST['name'];
$age = $_POST['age'];
$gender = $_POST["gender"];
$email = $_POST['email'];
$phone = $_POST['phone'];
$desc = $_POST['desc'];

$sql = "INSERT INTO `trip`.`trip` ( `name`, `age`, `gender`, `email`, `phone`, `desc`, `dt`) VALUES ( '$name', '$age', '$gender', '$email', '$phone', '$desc', current_timestamp())"; 
// echo $sql;
if($conn-> query($sql) == true){
    // echo "successfully  inserted";
    $insert = true;
}
else{
    echo "ERROR $sql <br> $conn->error";
}
$conn-> close();
}
?>



